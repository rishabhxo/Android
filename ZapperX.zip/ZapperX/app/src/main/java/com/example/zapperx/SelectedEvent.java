package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.widget.TextView;

public class SelectedEvent extends AppCompatActivity {
TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_event);
        TextView tv1 = (TextView) findViewById(R.id.tvlong1);
        tv1.setMovementMethod(new ScrollingMovementMethod());
    }
}
