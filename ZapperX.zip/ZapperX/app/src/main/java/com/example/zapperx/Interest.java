package com.example.zapperx;

public class Interest {
    private String interest;

    public Interest(String interest) {
        this.interest = interest;
    }

    public String getInterest() {
        return this.interest;
    }
}