package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import static android.content.SharedPreferences.*;

public class MainActivity extends AppCompatActivity {

    EditText email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = (EditText)findViewById(R.id.emailid);
        password   = (EditText)findViewById(R.id.pass);


    }

    public void gotologin(View v)
    {
        if (email.getText().toString().trim().equals("") || password.getText().toString().trim().equals(""))
        {
            Toast.makeText(this,"Empty fields are not allowed.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            //shared preference

            Editor editor = getSharedPreferences("userdetails", MODE_PRIVATE).edit();

            editor.putString("emaildata", email.getText().toString());
            editor.putString("passworddata", password.getText().toString());
            editor.commit();


            Intent i = new Intent(this,Login.class);
            startActivity(i);
        }

    }
    public void gotologin1(View v)
    {
        Intent i = new Intent(this,Login.class);
        startActivity(i);
    }

}
