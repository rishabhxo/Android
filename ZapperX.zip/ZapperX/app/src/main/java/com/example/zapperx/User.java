package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class User extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);
    }

    public void gotoselected(View v) {
        Intent i = new Intent(this, Selected.class);
        startActivity(i);
    }

    public void gotoopen(View v) {
        Intent i = new Intent(this, Open.class);
        startActivity(i);
    }

    public void gotosearch(View v) {
        Intent i = new Intent(this, Search.class);
        startActivity(i);
    }

    @Override
    protected void onPause() {
        super.onPause();
        Toast.makeText(this, "Zapper is on PAUSE ", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onResume() {
        super.onResume();
        Toast.makeText(this, "Zapper is resumed ", Toast.LENGTH_LONG).show();
    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        Toast.makeText(this, "Zapper is destroyed", Toast.LENGTH_LONG).show();    }
}

