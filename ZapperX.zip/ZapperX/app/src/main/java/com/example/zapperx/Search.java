package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.view.View;
import android.widget.ListView;
import android.widget.SearchView;
import java.util.ArrayList;
import android.os.Bundle;
public class Search extends AppCompatActivity implements SearchView.OnQueryTextListener {

    ListView list;
    ListViewAdapter adapter;
    SearchView editsearch;
    String[] interestList;
    ArrayList<Interest> arraylist = new ArrayList<Interest>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        interestList = new String[]{"Music", "Technology", "Fitness",
                "Reading", "Photography", "Film", "Writing", "Gaming",
                "Painting","Producing","Entrepreneur"};

        list = (ListView) findViewById(R.id.listview);

        for (int i = 0; i < interestList.length; i++) {
            Interest interest = new Interest(interestList[i]);
            // Binds all strings into an array
            arraylist.add(interest);

            adapter = new ListViewAdapter(this, arraylist);

            list.setAdapter(adapter);

            editsearch = (SearchView) findViewById(R.id.search);
            editsearch.setOnQueryTextListener(this);
        }


    }
    @Override
    public boolean onQueryTextSubmit(String query) {

        return false;
    }
    @Override
    public boolean onQueryTextChange(String newText) {
        String text = newText;
        adapter.filter(text);
        return false;
    }

}
