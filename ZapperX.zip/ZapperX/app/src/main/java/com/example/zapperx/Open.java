package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class Open extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open);
    }

    public void gotoselectedevent(View v) {
        Intent i = new Intent(this, SelectedEvent.class);
        startActivity(i);
    }

    public void gotocategories(View v) {
        Intent i = new Intent(this, GridLayout.class);
        startActivity(i);
    }

    public void gotouser(View v) {
        Intent i = new Intent(this, User.class);
        startActivity(i);
    }
}


