package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Login extends AppCompatActivity {

    EditText email, password;
    String em, pd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        email   = (EditText)findViewById(R.id.loginemail);
        password   = (EditText)findViewById(R.id.loginpassword);

        SharedPreferences prefs = getSharedPreferences("userdetails", MODE_PRIVATE);
        String emaildetail = prefs.getString("emaildata", null);
        String passworddetail= prefs.getString("passworddata", null);


        if (emaildetail != null) {

            if (passworddetail != null)
            {
                em = prefs.getString("emaildata", "No name defined");//"No name defined" is the default value.
                pd = prefs.getString("passworddata", "No name defined"); //0 is the default value.
            }
            else
            {
                Toast.makeText(this,"Empty field not allowed.",Toast.LENGTH_SHORT).show();
            }
        }
        else {
            Toast.makeText(this,"Empty field not allowed.",Toast.LENGTH_SHORT).show();
        }

    }
    public void gotosignup(View v){
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
    public void gotohome(View v){

        if (email.getText().toString().trim().equals("") || password.getText().toString().trim().equals(""))
        {
            Toast.makeText(this,"Empty fields are not allowed.",Toast.LENGTH_SHORT).show();
        }
        else
        {
            if (email.getText().toString().equals(em) && (password.getText().toString().equals(pd)) )
            {
                    Intent i=new Intent(this,Open.class);
                    startActivity(i);
            }
            else
            {
                Toast.makeText(this,"User details do not match.",Toast.LENGTH_SHORT).show();
            }

        }


    }

    @Override
    protected void onStart() {
        super.onStart();
        Toast.makeText(this, "Zapper has started ", Toast.LENGTH_LONG).show();
    }
}
