package com.example.zapperx;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class GridLayout extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_layout);
    }
    public void gotoselected(View v) {
        Intent i = new Intent(this, Selected.class);
        startActivity(i);
    }
    public void gotosearch(View v) {
        Intent i = new Intent(this, Search.class);
        startActivity(i);
    }
}
